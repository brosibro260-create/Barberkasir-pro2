package com.brosibro.barbershop;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout content;
    DB db;
    SharedPreferences pref;
    ArrayList<Service> services = new ArrayList<>();
    double barberPct=40, ownerPct=60;

    static class Service { int id,price; String name; Service(int i,String n,int p){id=i;name=n;price=p;} }
    static class CartItem { Service s; int qty; CartItem(Service x){s=x;qty=1;} }

    String rupiah(long n){ return NumberFormat.getCurrencyInstance(new Locale("id","ID")).format(n).replace(",00",""); }
    TextView tv(String s,int size){ TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(18,14,18,14);return t; }
    Button btn(String s){ Button b=new Button(this);b.setText(s);b.setTextColor(Color.BLACK);b.setTextSize(14);b.setBackgroundColor(Color.rgb(244,185,66));return b; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b); db=new DB(this); pref=getSharedPreferences("app",0);
        seed(); barberPct=pref.getFloat("barber",40); ownerPct=100-barberPct; build(); home();
    }
    void seed(){
        if(db.countServices()==0){
            String[] n={"Potong","Potong + Keramas","Hair Light","Semir","Crembath","Toning","Hair Light Fashion","Bleaching Full","Hair Mask","Hair Clay Kecil","Hair Clay Besar","Pomade"};
            int[] p={25000,30000,100000,50000,30000,50000,150000,150000,30000,30000,40000,40000};
            for(int i=0;i<n.length;i++) db.addService(n[i],p[i]);
        }
        if(db.countBarbers()==0){ db.addBarber("Andi");db.addBarber("Rizky");db.addBarber("Dika");db.addBarber("Budi"); }
    }
    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(11,15,18));
        LinearLayout top=new LinearLayout(this);top.setPadding(8,5,8,5);
        TextView title=tv(pref.getString("shop","Brosibro Barbershop"),20);top.addView(title,new LinearLayout.LayoutParams(0,62,1));
        Button s=btn("⚙");s.setOnClickListener(v->settings());top.addView(s,new LinearLayout.LayoutParams(70,62));root.addView(top);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    void clear(){content.removeAllViews();}
    void back(){ home(); }

    void home(){
        clear(); content.addView(tv("💈 KASIR & MANAJEMEN",24));
        long today=db.sumSince(dayStart()), count=db.countSince(dayStart());
        content.addView(tv("Omzet Hari Ini\n"+rupiah(today)+"\nTransaksi: "+count,20));
        String[] labels={"🧾 Transaksi Kasir","✂ Daftar Layanan","👤 Data Barber","📊 Laporan","💰 Pembagian Hasil","🧾 Riwayat Transaksi","⚙ Pengaturan"};
        View.OnClickListener[] ls={v->cashier(),v->services(),v->barbers(),v->reports(),v->split(),v->history(),v->settings()};
        for(int i=0;i<labels.length;i++){Button b=btn(labels[i]);b.setOnClickListener(ls[i]);content.addView(b,new LinearLayout.LayoutParams(-1,57));}
    }

    long dayStart(){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();}

    void loadServices(){services.clear();Cursor c=db.services();while(c.moveToNext())services.add(new Service(c.getInt(0),c.getString(1),c.getInt(2)));c.close();}

    void services(){
        clear();loadServices();content.addView(tv("Daftar Layanan & Harga",22));
        Button add=btn("+ Tambah Layanan");add.setOnClickListener(v->editService(null));content.addView(add);
        for(Service s:services){LinearLayout r=new LinearLayout(this);TextView t=tv(s.name+"\n"+rupiah(s.price),16);r.addView(t,new LinearLayout.LayoutParams(0,72,1));
            Button e=btn("Edit");e.setOnClickListener(v->editService(s));r.addView(e,new LinearLayout.LayoutParams(90,60));content.addView(r);}
        Button b=btn("← Beranda");b.setOnClickListener(v->back());content.addView(b);
    }
    void editService(Service old){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        EditText n=new EditText(this),p=new EditText(this);n.setHint("Nama layanan");p.setHint("Harga");p.setInputType(2);n.setTextColor(Color.WHITE);p.setTextColor(Color.WHITE);
        if(old!=null){n.setText(old.name);p.setText(""+old.price);}box.addView(n);box.addView(p);
        new AlertDialog.Builder(this).setTitle(old==null?"Tambah Layanan":"Edit Layanan").setView(box)
        .setPositiveButton("Simpan",(d,w)->{try{String name=n.getText().toString().trim();int price=Integer.parseInt(p.getText().toString());if(old==null)db.addService(name,price);else db.updateService(old.id,name,price);services();}catch(Exception e){}})
        .setNegativeButton("Batal",null).show();
    }

    void cashier(){
        loadServices();final ArrayList<CartItem> cart=new ArrayList<>();clear();content.addView(tv("Transaksi Kasir",22));
        TextView total=tv("Total: Rp 0",20);content.addView(total);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        for(Service s:services){Button b=btn(s.name+"  •  "+rupiah(s.price));b.setOnClickListener(v->{CartItem found=null;for(CartItem x:cart)if(x.s.id==s.id)found=x;if(found==null)cart.add(new CartItem(s));else found.qty++;refreshCart(list,total,cart);});content.addView(b);}
        Button pay=btn("💳 Lanjut Pembayaran");pay.setOnClickListener(v->{if(cart.isEmpty())return;payment(cart);});content.addView(pay);
        Button back=btn("← Beranda");back.setOnClickListener(v->home());content.addView(back);
    }
    void refreshCart(LinearLayout list,TextView total,ArrayList<CartItem> cart){
        list.removeAllViews();long sum=0;for(CartItem x:cart){sum+=(long)x.s.price*x.qty;list.addView(tv(x.s.name+" x"+x.qty+"  "+rupiah((long)x.s.price*x.qty),16));}total.setText("Total: "+rupiah(sum));
    }
    long cartTotal(ArrayList<CartItem> c){long s=0;for(CartItem x:c)s+=(long)x.s.price*x.qty;return s;}

    void payment(ArrayList<CartItem> cart){
        long total=cartTotal(cart);
        final String[] method={"Tunai"};
        String[] opts={"Tunai","QRIS","Transfer","E-Wallet"};
        new AlertDialog.Builder(this).setTitle("Pembayaran • "+rupiah(total))
        .setSingleChoiceItems(opts,0,(d,w)->method[0]=opts[w])
        .setPositiveButton("Bayar & Simpan",(d,w)->{long id=db.addTransaction(total,method[0],barberPct);for(CartItem x:cart)db.addItem(id,x.s.name,x.qty,x.s.price);receipt(id,total,method[0]);})
        .setNegativeButton("Batal",null).show();
    }
    void receipt(long id,long total,String method){
        long barber=Math.round(total*barberPct/100),owner=total-barber;
        String r="BROSIBRO BARBERSHOP\nSTRUK TRANSAKSI\nNo: "+id+"\nTanggal: "+new Date()+"\n\nTotal: "+rupiah(total)+"\nPembayaran: "+method+
        "\n\nBagian Barber ("+(int)barberPct+"%): "+rupiah(barber)+"\nBagian Owner ("+(int)ownerPct+"%): "+rupiah(owner)+"\n\nTerima kasih!";
        new AlertDialog.Builder(this).setTitle("Struk").setMessage(r).setPositiveButton("Bagikan",(d,w)->share(r)).setNegativeButton("Selesai",(d,w)->home()).show();
    }
    void share(String text){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,text);startActivity(Intent.createChooser(i,"Bagikan struk"));}

    void barbers(){
        clear();content.addView(tv("Data Barber",22));Cursor c=db.barbers();while(c.moveToNext())content.addView(tv("👤 "+c.getString(1)+"\nStatus: Aktif • Bagi hasil: "+(int)barberPct+"%",17));c.close();
        Button add=btn("+ Tambah Barber");add.setOnClickListener(v->addBarber());content.addView(add);Button b=btn("← Beranda");b.setOnClickListener(v->home());content.addView(b);
    }
    void addBarber(){EditText e=new EditText(this);e.setHint("Nama barber");e.setTextColor(Color.WHITE);new AlertDialog.Builder(this).setTitle("Tambah Barber").setView(e).setPositiveButton("Simpan",(d,w)->{if(!e.getText().toString().trim().isEmpty())db.addBarber(e.getText().toString().trim());barbers();}).setNegativeButton("Batal",null).show();}

    void split(){
        clear();content.addView(tv("Pembagian Hasil",22));
        long omzet=db.sumSince(dayStart());long barber=Math.round(omzet*barberPct/100);
        content.addView(tv("Omzet hari ini: "+rupiah(omzet)+"\nBarber ("+(int)barberPct+"%): "+rupiah(barber)+"\nOwner ("+(int)ownerPct+"%): "+rupiah(omzet-barber),20));
        Button set=btn("⚙ Atur Persentase");set.setOnClickListener(v->setSplit());content.addView(set);
        Button b=btn("← Beranda");b.setOnClickListener(v->home());content.addView(b);
    }
    void setSplit(){
        EditText e=new EditText(this);e.setInputType(2);e.setText(""+(int)barberPct);e.setTextColor(Color.WHITE);
        new AlertDialog.Builder(this).setTitle("Persentase Barber").setMessage("Owner otomatis = 100% - barber").setView(e).setPositiveButton("Simpan",(d,w)->{try{double x=Double.parseDouble(e.getText().toString());if(x<0||x>100)throw new Exception();barberPct=x;ownerPct=100-x;pref.edit().putFloat("barber",(float)x).apply();split();}catch(Exception z){}}).setNegativeButton("Batal",null).show();
    }

    void reports(){
        clear();content.addView(tv("Laporan Omzet",22));
        Calendar now=Calendar.getInstance();long day=dayStart(), week=day-6L*24*60*60*1000, month=day-29L*24*60*60*1000;
        long d=db.sumSince(day),w=db.sumSince(week),m=db.sumSince(month);
        content.addView(tv("Hari ini\n"+rupiah(d)+" • "+db.countSince(day)+" transaksi\n\n7 hari terakhir\n"+rupiah(w)+" • "+db.countSince(week)+" transaksi\n\n30 hari terakhir\n"+rupiah(m)+" • "+db.countSince(month)+" transaksi",19));
        Button b=btn("← Beranda");b.setOnClickListener(v->home());content.addView(b);
    }

    void history(){
        clear();content.addView(tv("Riwayat Transaksi",22));Cursor c=db.transactions();SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault());
        while(c.moveToNext()){long id=c.getLong(0),total=c.getLong(1),time=c.getLong(3);TextView t=tv("#"+id+"  "+rupiah(total)+"\n"+f.format(new Date(time))+" • "+c.getString(2),16);t.setOnClickListener(v->receipt(id,total,c.getString(2)));content.addView(t);}c.close();
        Button b=btn("← Beranda");b.setOnClickListener(v->home());content.addView(b);
    }

    void settings(){
        clear();content.addView(tv("Pengaturan",22));
        Button n=btn("🏪 Ubah Nama Barbershop");n.setOnClickListener(v->changeName());content.addView(n);
        Button s=btn("💰 Pembagian Hasil");s.setOnClickListener(v->split());content.addView(s);
        Button l=btn("✂ Layanan & Harga");l.setOnClickListener(v->services());content.addView(l);
        Button b=btn("← Beranda");b.setOnClickListener(v->home());content.addView(b);
    }
    void changeName(){
        EditText e=new EditText(this);e.setText(pref.getString("shop","Brosibro Barbershop"));e.setTextColor(Color.WHITE);
        new AlertDialog.Builder(this).setTitle("Nama Barbershop").setView(e).setPositiveButton("Simpan",(d,w)->{pref.edit().putString("shop",e.getText().toString()).apply();build();home();}).setNegativeButton("Batal",null).show();
    }
}