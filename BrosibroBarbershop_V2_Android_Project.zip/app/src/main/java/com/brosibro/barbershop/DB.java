package com.brosibro.barbershop;
import android.content.*;
import android.database.sqlite.*;
import android.database.Cursor;

public class DB extends SQLiteOpenHelper {
    DB(Context c){super(c,"barbershop.db",null,1);}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE services(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,price INTEGER)");
        d.execSQL("CREATE TABLE barbers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT)");
        d.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,total INTEGER,payment TEXT,created INTEGER,barberPct REAL)");
        d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,txId INTEGER,name TEXT,qty INTEGER,price INTEGER)");
    }
    public void onUpgrade(SQLiteDatabase d,int o,int n){}
    int countServices(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM services",null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
    int countBarbers(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM barbers",null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
    void addService(String n,int p){getWritableDatabase().execSQL("INSERT INTO services(name,price) VALUES(?,?)",new Object[]{n,p});}
    void updateService(int id,String n,int p){getWritableDatabase().execSQL("UPDATE services SET name=?,price=? WHERE id=?",new Object[]{n,p,id});}
    Cursor services(){return getReadableDatabase().rawQuery("SELECT id,name,price FROM services ORDER BY id",null);}
    void addBarber(String n){getWritableDatabase().execSQL("INSERT INTO barbers(name) VALUES(?)",new Object[]{n});}
    Cursor barbers(){return getReadableDatabase().rawQuery("SELECT id,name FROM barbers ORDER BY id",null);}
    long addTransaction(long total,String payment,double pct){ContentValues v=new ContentValues();v.put("total",total);v.put("payment",payment);v.put("created",System.currentTimeMillis());v.put("barberPct",pct);return getWritableDatabase().insert("transactions",null,v);}
    void addItem(long tx,String n,int q,int p){ContentValues v=new ContentValues();v.put("txId",tx);v.put("name",n);v.put("qty",q);v.put("price",p);getWritableDatabase().insert("items",null,v);}
    long sumSince(long t){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM transactions WHERE created>=?",new String[]{""+t});c.moveToFirst();long x=c.getLong(0);c.close();return x;}
    long countSince(long t){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM transactions WHERE created>=?",new String[]{""+t});c.moveToFirst();long x=c.getLong(0);c.close();return x;}
    Cursor transactions(){return getReadableDatabase().rawQuery("SELECT id,total,payment,created FROM transactions ORDER BY id DESC",null);}
}