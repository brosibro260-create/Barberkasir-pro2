# Brosibro Barbershop V2

Versi lanjutan prototipe APK kasir:
- Database SQLite lokal, sehingga transaksi tersimpan setelah aplikasi ditutup.
- Daftar layanan/harga dapat ditambah dan diedit.
- Transaksi dengan keranjang dan jumlah layanan.
- Pembayaran: Tunai, QRIS, Transfer, E-Wallet.
- Struk transaksi dapat dibagikan melalui menu Share Android.
- Riwayat transaksi.
- Laporan omzet hari ini, 7 hari, dan 30 hari.
- Pembagian hasil barber/owner dengan persentase yang dapat diubah.
- Data barber.
- Nama barbershop dapat diganti kapan saja.

## Build
Buka folder ini di Android Studio, Sync Project with Gradle Files, lalu:
Build > Build APK(s)

Output:
app/build/outputs/apk/debug/app-debug.apk

Catatan:
Ini adalah V2 yang berfokus pada fungsi kasir inti dan database lokal. Integrasi printer thermal Bluetooth, QRIS dinamis, backup cloud, login PIN, stok produk, dan ekspor PDF/Excel dapat ditambahkan pada V3.
